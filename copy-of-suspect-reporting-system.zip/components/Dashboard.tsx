import React, { useState, useEffect, useRef } from 'react';
import { ReportData } from '../types';
import { logError } from '../services/errorReporting';

declare const L: any;
declare global {
    interface Window {
        jspdf: {
            jsPDF: any;
        };
        QRCode: any;
    }
}

// Mock data for initial view
const createMockReport = (id: number): ReportData => ({
    caseId: `MH-PUN-${new Date().getFullYear()}-00${id}`,
    reportType: id % 2 === 0 ? 'Illegal Immigrant' : 'Suspicious Person',
    priority: Math.random() > 0.7 ? 'HIGH' : 'LOW',
    credibilityScore: 45 + Math.floor(Math.random() * 55),
    submissionTimestamp: new Date(Date.now() - Math.random() * 1000 * 3600 * 24 * 7),
    reporter: { 
        tier: 'Tier 2', 
        name: `Reporter ${id}`, 
        phone: '9876543210', 
        phoneHash: `a1b2c3d4e5f6...${id}`, 
        ipAddress: '192.168.1.1', 
        deviceFingerprint: `fp_mock_${id}`,
        browserMetadata: {
            userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            platform: "Win32",
            language: "en-US",
            vendor: "Google Inc.",
            cookiesEnabled: true,
            doNotTrack: null,
            screenResolution: "1920x1080",
            colorDepth: 24,
            pixelDepth: 24,
            deviceMemory: "8",
            hardwareConcurrency: "8",
            connectionType: "4g"
        }
    },
    suspect: {
        name: `Suspect ${id}`, age: `${20 + id}`, gender: 'Male',
        clothing: 'Blue shirt, black pants', language: 'Unknown',
        skinColor: 'Fair', eyeColor: 'Brown', height: '5ft 9in',
        facialDetails: 'Short beard', visibleMarks: 'Tattoo on left arm',
        distinguishingFeatures: 'Walks with a slight limp.',
        vehicleDetails: `Silver sedan, license plate MH12AB123${id}`
    },
    location: {
        autoGps: { latitude: 18.5204 + (Math.random() - 0.5) * 0.1, longitude: 73.8567 + (Math.random() - 0.5) * 0.1 },
        state: 'Maharashtra', city: 'Pune', pincode: '411001',
        manualAddress: `Near Pune Station, Mock Address ${id}`,
        landmarkPhoto: null, dateTime: new Date(),
        description: `Mock description for report ${id}. This is a sample text to fill the space.`
    },
    evidencePhotos: [],
    riskFactors: id === 1 ? ['High-risk location'] : [],
    triageStatus: 'Pending',
    reportStatus: 'Pending'
});
const MOCK_REPORTS = Array.from({ length: 5 }, (_, i) => createMockReport(i + 1));

const fileToDataUrl = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const generatePdfReport = async (report: ReportData) => {
    try {
        if (typeof window.QRCode === 'undefined') {
            const err = new Error('QRCode library not found during PDF generation.');
            logError(err, { component: 'Dashboard', function: 'generatePdfReport' });
            alert('QR Code generation library is not available. Please try again.');
            return;
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // --- Add QR Code ---
        let qrCodeImage: string | undefined;
        try {
            qrCodeImage = await new Promise<string>((resolve, reject) => {
                const qrCodeContainer = document.createElement('div');
                qrCodeContainer.style.display = 'none';
                document.body.appendChild(qrCodeContainer);

                const timeout = setTimeout(() => {
                    try { document.body.removeChild(qrCodeContainer); } catch(e) {}
                    reject(new Error('QR Code generation timed out.'));
                }, 3000); // 3-second timeout

                try {
                    new window.QRCode(qrCodeContainer, {
                        text: `CaseID: ${report.caseId}\nStatus: ${report.reportStatus}`,
                        width: 128,
                        height: 128,
                        correctLevel: (window.QRCode as any).CorrectLevel.H,
                        onRenderingEnd: (_: any, dataURL: string) => {
                            clearTimeout(timeout);
                            try { document.body.removeChild(qrCodeContainer); } catch(e) {}
                            resolve(dataURL);
                        }
                    });
                } catch (e) {
                    clearTimeout(timeout);
                    try { document.body.removeChild(qrCodeContainer); } catch(e) {}
                    reject(e);
                }
            });
        } catch(e) {
            // Log the error, but don't stop PDF generation
            logError(e, { component: 'Dashboard', function: 'generatePdfReport (QRCode)', caseId: report.caseId });
            console.warn("QR Code generation failed. Continuing without it.", e);
        }

        // --- PDF Content ---
        doc.setFontSize(18);
        doc.text('CONFIDENTIAL - POLICE REPORT', 105, 20, { align: 'center' });

        if (qrCodeImage) {
            doc.addImage(qrCodeImage, 'PNG', 160, 25, 35, 35);
        }
        
        doc.setFontSize(14);
        doc.text(`Case ID: ${report.caseId}`, 20, 40);
        doc.text(`Priority: ${report.priority}`, 20, 48);
        doc.text(`Credibility Score: ${report.credibilityScore}`, 20, 56);

        doc.setLineWidth(0.5);
        doc.line(20, 65, 190, 65);

        let yPos = 75;
        const addSection = (title: string, data: [string, any][]) => {
            if (yPos > 260) {
              doc.addPage();
              yPos = 20;
            }
            doc.setFontSize(12);
            doc.setFont(undefined, 'bold');
            doc.text(title, 20, yPos);
            yPos += 7;
            doc.setFont(undefined, 'normal');
            data.forEach(([label, value]) => {
                if (value && yPos < 280) {
                    doc.text(`${label}:`, 25, yPos);
                    const textLines = doc.splitTextToSize(String(value), 115);
                    doc.text(textLines, 70, yPos);
                    yPos += (textLines.length * 4) + 2;
                } else if (value && yPos >= 280) {
                    doc.addPage();
                    yPos = 20;
                    doc.text(`${label}:`, 25, yPos);
                    const textLines = doc.splitTextToSize(String(value), 115);
                    doc.text(textLines, 70, yPos);
                    yPos += (textLines.length * 4) + 2;
                }
            });
            yPos += 5;
        };
        
        addSection("Suspect Details", [
            ['Name', report.suspect.name], ['Age', report.suspect.age], ['Gender', report.suspect.gender],
            ['Description', `${report.suspect.height}, ${report.suspect.skinColor} skin, ${report.suspect.eyeColor} eyes`],
            ['Clothing', report.suspect.clothing], ['Language', report.suspect.language],
            ['Facial Details', report.suspect.facialDetails], ['Visible Marks', report.suspect.visibleMarks],
            ['Features', report.suspect.distinguishingFeatures], ['Vehicle', report.suspect.vehicleDetails]
        ]);
        
        addSection("Location & Sighting", [
            ['Timestamp', report.location.dateTime.toLocaleString()],
            ['GPS', report.location.autoGps ? `${report.location.autoGps.latitude.toFixed(5)}, ${report.location.autoGps.longitude.toFixed(5)}` : 'N/A'],
            ['Address', `${report.location.manualAddress}, ${report.location.city}, ${report.location.state} - ${report.location.pincode}`],
            ['Description', report.location.description]
        ]);

        addSection("Reporter Information", [
            ['Tier', report.reporter.tier], ['Name', report.reporter.name], ['Phone', report.reporter.phone],
            ['Phone Hash', report.reporter.phoneHash]
        ]);

        addSection("System & Browser Metadata", [
            ['IP Address', report.reporter.ipAddress],
            ['Device Fingerprint', report.reporter.deviceFingerprint],
            ['User Agent', report.reporter.browserMetadata.userAgent],
            ['Platform', report.reporter.browserMetadata.platform],
            ['Language', report.reporter.browserMetadata.language],
            ['Screen Resolution', report.reporter.browserMetadata.screenResolution],
            ['Color Depth', report.reporter.browserMetadata.colorDepth],
            ['Cookies Enabled', report.reporter.browserMetadata.cookiesEnabled],
            ['Do Not Track', report.reporter.browserMetadata.doNotTrack],
            ['Device Memory (GB)', report.reporter.browserMetadata.deviceMemory],
            ['CPU Cores', report.reporter.browserMetadata.hardwareConcurrency],
            ['Connection Type', report.reporter.browserMetadata.connectionType],
        ]);

        // --- Add Photos ---
        if (report.location.landmarkPhoto || report.evidencePhotos.length > 0) {
            doc.addPage();
            let photoYPos = 20;
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.text("Attached Media", 105, photoYPos, { align: 'center' });
            photoYPos += 15;

            const addImageToPdf = async (file: File, title: string) => {
                const dataUrl = await fileToDataUrl(file);
                const img = new Image();
                img.src = dataUrl;
                await new Promise(resolve => { img.onload = resolve; });

                const maxWidth = 170;
                const maxHeight = 100;
                let imgWidth = img.width;
                let imgHeight = img.height;
                
                if (imgWidth > maxWidth) {
                    const ratio = maxWidth / imgWidth;
                    imgWidth = maxWidth;
                    imgHeight *= ratio;
                }
                if (imgHeight > maxHeight) {
                    const ratio = maxHeight / imgHeight;
                    imgHeight = maxHeight;
                    imgWidth *= ratio;
                }

                if (photoYPos + imgHeight > 280) {
                    doc.addPage();
                    photoYPos = 20;
                }
                
                doc.setFontSize(10);
                doc.setFont(undefined, 'normal');
                doc.text(title, 20, photoYPos);
                photoYPos += 5;
                doc.addImage(dataUrl, 'JPEG', 20, photoYPos, imgWidth, imgHeight);
                photoYPos += imgHeight + 10;
            };

            if (report.location.landmarkPhoto) {
                await addImageToPdf(report.location.landmarkPhoto.file, `Landmark Photo: ${report.location.landmarkPhoto.file.name}`);
            }

            for (let i = 0; i < report.evidencePhotos.length; i++) {
                const photo = report.evidencePhotos[i];
                await addImageToPdf(photo.file, `Evidence Photo ${i + 1}: ${photo.file.name}`);
            }
        }


        doc.save(`Report-${report.caseId}.pdf`);
    } catch (error) {
        logError(error, {
            component: 'Dashboard',
            function: 'generatePdfReport',
            context: `Failed while generating PDF for Case ID: ${report.caseId}`,
        });
        alert('An unexpected error occurred while generating the PDF report. The issue has been logged for review.');
    }
};


// --- Components ---

const ReportModal: React.FC<{ report: ReportData | null, onClose: () => void, onMarkAsFalse: (report: ReportData) => void }> = ({ report, onClose, onMarkAsFalse }) => {
    const modalRef = useRef<HTMLDivElement>(null);
    const closeButtonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        if (report) {
            const handleKeyDown = (event: KeyboardEvent) => {
                if (event.key === 'Escape') {
                    onClose();
                }
                if (event.key === 'Tab') {
                    const focusableElements = modalRef.current?.querySelectorAll<HTMLElement>(
                        'a[href], button, textarea, input, select'
                    );
                    if (!focusableElements || focusableElements.length === 0) return;

                    const firstElement = focusableElements[0];
                    const lastElement = focusableElements[focusableElements.length - 1];

                    if (!event.shiftKey && document.activeElement === lastElement) {
                        firstElement.focus();
                        event.preventDefault();
                    }

                    if (event.shiftKey && document.activeElement === firstElement) {
                        lastElement.focus();
                        event.preventDefault();
                    }
                }
            };

            // Focus the close button when the modal opens
            closeButtonRef.current?.focus();

            document.addEventListener('keydown', handleKeyDown);
            return () => {
                document.removeEventListener('keydown', handleKeyDown);
            };
        }
    }, [report, onClose]);

    if (!report) return null;

    const DetailItem: React.FC<{label: string, value: any, className?: string}> = ({ label, value, className }) => (
        <div className={className}>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</p>
            <p className="mt-1 text-sm text-gray-900 dark:text-gray-200">{value || 'N/A'}</p>
        </div>
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4" role="dialog" aria-modal="true" aria-labelledby="modal-title">
            <div ref={modalRef} className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-full overflow-y-auto">
                <div className="p-6">
                    <div className="flex justify-between items-start">
                        <div>
                            <h3 id="modal-title" className="text-2xl font-bold text-brand-800 dark:text-brand-300">{report.caseId}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{report.reportType}</p>
                            <span className={`mt-1 mr-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${report.priority === 'HIGH' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                {report.priority} (Score: {report.credibilityScore})
                            </span>
                             {report.riskFactors.length > 0 && <span className="mt-1 px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">{report.riskFactors.join(', ')}</span>}
                        </div>
                        <button ref={closeButtonRef} onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 text-3xl" aria-label="Close modal">&times;</button>
                    </div>

                    <div className="mt-6 border-t border-gray-200 dark:border-gray-700">
                        <dl className="divide-y divide-gray-200 dark:divide-gray-700">
                             <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                                <h4 className="text-md font-semibold text-gray-700 dark:text-gray-300 md:col-span-3">Suspect Details</h4>
                                <DetailItem label="Name" value={report.suspect.name} />
                                <DetailItem label="Age" value={report.suspect.age} />
                                <DetailItem label="Gender" value={report.suspect.gender} />
                                <DetailItem label="Height" value={report.suspect.height} />
                                <DetailItem label="Skin Color" value={report.suspect.skinColor} />
                                <DetailItem label="Eye Color" value={report.suspect.eyeColor} />
                                <DetailItem label="Clothing" value={report.suspect.clothing} />
                                <DetailItem label="Language" value={report.suspect.language} />
                                <DetailItem label="Facial Details" value={report.suspect.facialDetails} />
                                <DetailItem label="Visible Marks" value={report.suspect.visibleMarks} />
                                <DetailItem label="Distinguishing Features" value={report.suspect.distinguishingFeatures} className="md:col-span-3" />
                                <DetailItem label="Vehicle Details" value={report.suspect.vehicleDetails} className="md:col-span-3"/>
                            </div>
                             <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                                <h4 className="text-md font-semibold text-gray-700 dark:text-gray-300 md:col-span-3">Location & Sighting</h4>
                                <DetailItem label="GPS Coordinates" value={report.location.autoGps ? `${report.location.autoGps.latitude.toFixed(5)}, ${report.location.autoGps.longitude.toFixed(5)}` : 'N/A'} />
                                <DetailItem label="State" value={report.location.state} />
                                <DetailItem label="City" value={report.location.city} />
                                <DetailItem label="Pincode" value={report.location.pincode} />
                                <DetailItem label="Manual Address" value={report.location.manualAddress} />
                                <DetailItem label="Sighting Time" value={report.location.dateTime.toLocaleString()} />
                                <DetailItem label="Description" value={report.location.description} className="md:col-span-3" />
                            </div>
                             <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                                <h4 className="text-md font-semibold text-gray-700 dark:text-gray-300 md:col-span-3">Status & Actions</h4>
                                <DetailItem label="Triage Status" value={report.triageStatus} />
                                <DetailItem label="Report Status" value={report.reportStatus} />
                                <div className="md:col-span-3 flex flex-wrap gap-2">
                                     <button onClick={() => onMarkAsFalse(report)} className="px-3 py-1 text-xs font-medium rounded-md text-white bg-red-600 hover:bg-red-700 disabled:bg-red-400" disabled={report.reportStatus === 'False Alarm'}>Mark as False Alarm</button>
                                </div>
                             </div>
                        </dl>
                    </div>
                </div>
                <div className="bg-gray-50 dark:bg-gray-900 px-6 py-3 flex justify-between items-center">
                    <button onClick={() => generatePdfReport(report)} className="px-4 py-2 text-sm font-medium rounded-md text-white bg-gray-700 hover:bg-gray-800">Generate PDF</button>
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium rounded-md text-white bg-brand-700 hover:bg-brand-800">Close</button>
                </div>
            </div>
        </div>
    );
};


const ReportTable: React.FC<{ reports: ReportData[], onViewReport: (report: ReportData) => void }> = ({ reports, onViewReport }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const reportsPerPage = 10;
    const totalPages = Math.ceil(reports.length / reportsPerPage);
    const paginatedReports = reports.slice((currentPage - 1) * reportsPerPage, currentPage * reportsPerPage);

    const goToNextPage = () => setCurrentPage(page => Math.min(page + 1, totalPages));
    const goToPrevPage = () => setCurrentPage(page => Math.max(page - 1, 1));

    return (
        <div>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Case ID</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Score</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Priority</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Date</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {paginatedReports.map((report) => (
                            <tr key={report.caseId} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{report.caseId}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{report.credibilityScore}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${report.priority === 'HIGH' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                        {report.priority}
                                    </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{report.submissionTimestamp.toLocaleDateString()}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button onClick={() => onViewReport(report)} className="text-brand-600 hover:text-brand-900 dark:text-brand-400 dark:hover:text-brand-200">View Details</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="py-3 flex items-center justify-between">
                <div className="flex-1 flex justify-between sm:hidden">
                    <button onClick={goToPrevPage} disabled={currentPage === 1} className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50">Previous</button>
                    <button onClick={goToNextPage} disabled={currentPage === totalPages} className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50">Next</button>
                </div>
                <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                            Showing <span className="font-medium">{(currentPage - 1) * reportsPerPage + 1}</span> to <span className="font-medium">{Math.min(currentPage * reportsPerPage, reports.length)}</span> of <span className="font-medium">{reports.length}</span> results
                        </p>
                    </div>
                    <div>
                        <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                            <button onClick={goToPrevPage} disabled={currentPage === 1} className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50">Previous</button>
                            <button onClick={goToNextPage} disabled={currentPage === totalPages} className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50">Next</button>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    );
}

const ReportMap: React.FC<{ reports: ReportData[] }> = ({ reports }) => {
    const mapContainer = useRef<HTMLDivElement>(null);
    const mapInstance = useRef<any | null>(null);

    useEffect(() => {
        if (mapContainer.current && !mapInstance.current) {
            mapInstance.current = L.map(mapContainer.current).setView([20.5937, 78.9629], 5);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(mapInstance.current);
        }

        if (mapInstance.current) {
            mapInstance.current.eachLayer((layer: any) => {
                 if (layer instanceof L.Marker) {
                    mapInstance.current?.removeLayer(layer);
                }
            });
            reports.forEach(report => {
                if (report.location.autoGps) {
                    const marker = L.marker([report.location.autoGps.latitude, report.location.autoGps.longitude])
                        .addTo(mapInstance.current!);
                    marker.bindPopup(`<b>${report.caseId}</b><br>Score: ${report.credibilityScore}`);
                }
            });
        }
    }, [reports]);

    return <div ref={mapContainer} className="h-96 w-full rounded-lg shadow-md" role="application" aria-label="Map showing locations of reports" />;
};


// --- Main Dashboard ---

const Dashboard: React.FC<{reports: ReportData[], onMarkAsFalse: (report: ReportData) => void}> = ({ reports: liveReports, onMarkAsFalse }) => {
  const [filter, setFilter] = useState('all');
  const [selectedReport, setSelectedReport] = useState<ReportData | null>(null);
  
  const allReports = [...MOCK_REPORTS, ...liveReports].sort((a,b) => b.submissionTimestamp.getTime() - a.submissionTimestamp.getTime());

  const filteredReports = allReports.filter(report => {
    if (filter === 'all') return true;
    if (filter === 'high') return report.priority === 'HIGH';
    if (filter === 'weekly') {
        const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000);
        return report.submissionTimestamp > sevenDaysAgo;
    }
    if (filter === 'recent') {
        const oneDayAgo = new Date(Date.now() - 24 * 3600 * 1000);
        return report.submissionTimestamp > oneDayAgo;
    }
    return true;
  });

  const handleExportCsv = () => {
    try {
        const headers = [
            "Case ID", "Report Type", "Priority", "Credibility Score", "Submission Timestamp",
            "Triage Status", "Report Status", "Risk Factors",
            "Reporter Tier", "Reporter Name", "Reporter Phone", "Reporter Phone Hash", "Reporter IP", "Reporter Fingerprint",
            "Suspect Name", "Suspect Age", "Suspect Gender", "Suspect Height", "Suspect Skin Color", "Suspect Eye Color",
            "Suspect Clothing", "Suspect Language", "Suspect Facial Details", "Suspect Visible Marks",
            "Suspect Distinguishing Features", "Suspect Vehicle",
            "GPS Latitude", "GPS Longitude", "State", "City", "Pincode", "Manual Address",
            "Sighting Timestamp", "Location Description",
            "Landmark Photo Filename", "Evidence Photo Filenames"
        ];
        
        const escapeCsvField = (field: any): string => {
            const str = String(field ?? ''); // handle null/undefined
            if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return `"${str.replace(/"/g, '""')}"`;
            }
            return str;
        };

        const rows = filteredReports.map(r => [
            r.caseId, r.reportType, r.priority, r.credibilityScore, r.submissionTimestamp.toISOString(),
            r.triageStatus, r.reportStatus, r.riskFactors.join('; '),
            r.reporter.tier, r.reporter.name, r.reporter.phone, r.reporter.phoneHash, r.reporter.ipAddress, r.reporter.deviceFingerprint,
            r.suspect.name, r.suspect.age, r.suspect.gender, r.suspect.height, r.suspect.skinColor, r.suspect.eyeColor,
            r.suspect.clothing, r.suspect.language, r.suspect.facialDetails, r.suspect.visibleMarks,
            r.suspect.distinguishingFeatures, r.suspect.vehicleDetails,
            r.location.autoGps?.latitude, r.location.autoGps?.longitude, r.location.state, r.location.city, r.location.pincode, r.location.manualAddress,
            r.location.dateTime.toISOString(), r.location.description,
            r.location.landmarkPhoto?.file.name,
            r.evidencePhotos.map(p => p.file.name).join('; ')
        ].map(escapeCsvField).join(','));

        const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "reports_export.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } catch (error) {
        logError(error, {
            component: 'Dashboard',
            function: 'handleExportCsv',
            context: `Failed while exporting ${filteredReports.length} reports to CSV.`,
        });
        alert('An unexpected error occurred while exporting the data. The issue has been logged for review.');
    }
  };

  return (
    <div className="space-y-8">
      <ReportModal report={selectedReport} onClose={() => setSelectedReport(null)} onMarkAsFalse={onMarkAsFalse} />
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <div className="sm:flex sm:justify-between sm:items-center">
            <div>
                <h2 className="text-2xl font-bold text-brand-800 dark:text-brand-300">NGO Dashboard</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">Review and manage submitted reports.</p>
            </div>
            <div className="mt-4 sm:mt-0 flex space-x-2">
                <button onClick={handleExportCsv} className="px-4 py-2 text-sm font-medium rounded-md text-white bg-brand-700 hover:bg-brand-800">Export CSV</button>
            </div>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">Reports Map</h3>
        <ReportMap reports={filteredReports} />
      </div>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <div className="sm:flex sm:items-center sm:justify-between mb-4">
            <h3 className="text-lg font-semibold">Filed Reports</h3>
             <div className="flex items-center space-x-2 mt-2 sm:mt-0">
                <label htmlFor="filter-select" className="text-sm font-medium text-gray-700 dark:text-gray-300">Filter by:</label>
                <select id="filter-select" onChange={(e) => setFilter(e.target.value)} value={filter} className="block rounded-md border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 shadow-sm sm:text-sm">
                    <option value="all">All Reports</option>
                    <option value="high">High Priority</option>
                    <option value="weekly">This Week's Batch</option>
                    <option value="recent">Last 24h</option>
                </select>
             </div>
        </div>
        <ReportTable reports={filteredReports} onViewReport={setSelectedReport} />
      </div>
    </div>
  );
};

export default Dashboard;