import React, { Component, ErrorInfo, ReactNode } from 'react';
import { logError } from '../services/errorReporting';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  // FIX: Initialized state as a class property. This resolves TypeScript errors where `this.state` and `this.props` were not being recognized on the component instance. This is a modern and clean way to handle state initialization in React class components.
  state: State = { hasError: false };

  static getDerivedStateFromError(_: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log the error with additional context from React
    logError(error, { componentStack: errorInfo.componentStack });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col justify-center items-center text-center p-4">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg max-w-lg">
                 <h1 className="text-3xl font-bold text-red-600 dark:text-red-400 mb-4">Application Error</h1>
                <p className="text-gray-700 dark:text-gray-300 mb-6">
                    We're sorry, but something went wrong. A critical error occurred which prevents the application from continuing.
                    Our technical team has been automatically notified.
                </p>
                <button
                    onClick={() => {
                        // Attempt to recover by reloading
                        window.location.reload();
                    }}
                    className="px-6 py-2 font-medium rounded-md text-white bg-brand-700 hover:bg-brand-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500"
                >
                    Reload Application
                </button>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-4">
                    If the problem persists, please try clearing your browser cache.
                </p>
            </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;