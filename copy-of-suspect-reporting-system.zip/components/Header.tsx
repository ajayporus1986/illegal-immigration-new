import React from 'react';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';

const ShieldIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
  </svg>
);

interface HeaderProps {
    view: 'form' | 'dashboard' | 'login';
    setView: (view: 'form' | 'dashboard' | 'login') => void;
    theme: 'light' | 'dark';
    toggleTheme: () => void;
    isAuthenticated: boolean;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ view, setView, theme, toggleTheme, isAuthenticated, onLogout }) => {
  return (
    <header className="bg-white dark:bg-gray-800 shadow-md">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center text-center">
            <ShieldIcon className="w-10 h-10 text-brand-600 mr-4" />
            <div>
              <h1 className="text-xl sm:text-3xl font-bold text-brand-700 dark:text-brand-300">Suspect Reporting System</h1>
              <p className="hidden sm:block text-gray-600 dark:text-gray-400 mt-1">Help secure our nation. Report suspicious individuals.</p>
            </div>
        </div>
        <div className="flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <MoonIcon className="w-6 h-6" /> : <SunIcon className="w-6 h-6" />}
            </button>
            {isAuthenticated ? (
               <button 
                  onClick={onLogout}
                  className="px-4 py-2 text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                  Logout
              </button>
            ) : (
               <button 
                  onClick={() => setView(view === 'form' ? 'login' : 'form')}
                  className="px-4 py-2 text-sm font-medium rounded-md text-white bg-brand-700 hover:bg-brand-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500"
              >
                  {view === 'form' ? 'NGO Dashboard' : 'New Report'}
              </button>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;