import React, { useState, useCallback, useEffect } from 'react';
import { ReportData, LocationCoords, IdentityTier, BrowserMetadata } from '../types';
import { INDIAN_STATES, STATE_CITY_MAP, HIGH_RISK_PINCODES, STATE_POLICE_EMAILS } from '../constants';
import { PersonIcon } from './icons/PersonIcon';
import { LocationIcon } from './icons/LocationIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { FlagIcon } from './icons/FlagIcon';
import { logError } from '../services/errorReporting';

declare const CryptoJS: any;

// --- Helper Functions ---
const generateCaseId = () => `MH-PUN-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 90000) + 10000).padStart(5, '0')}`;
const hashData = (data: string) => CryptoJS.SHA256(data).toString(CryptoJS.enc.Hex);
const readFileAsArrayBuffer = (file: File): Promise<ArrayBuffer> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as ArrayBuffer);
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
    });
};
const hashFile = async (file: File): Promise<string> => {
    const buffer = await readFileAsArrayBuffer(file);
    const wordArray = CryptoJS.lib.WordArray.create(buffer);
    return CryptoJS.SHA256(wordArray).toString(CryptoJS.enc.Hex);
};
const getDeviceFingerprint = () => {
    const fingerprint = [
        navigator.userAgent,
        navigator.language,
        window.screen.width,
        window.screen.height,
        new Date().getTimezoneOffset()
    ].join('-');
    return hashData(fingerprint);
};
const getBrowserMetadata = (): BrowserMetadata => {
    const { userAgent, platform, language, vendor } = navigator;
    const { width, height, colorDepth, pixelDepth } = window.screen;
    const connection = (navigator as any).connection || {};

    return {
        userAgent,
        platform,
        language,
        vendor,
        cookiesEnabled: navigator.cookieEnabled,
        doNotTrack: navigator.doNotTrack,
        screenResolution: `${width}x${height}`,
        colorDepth,
        pixelDepth,
        deviceMemory: (navigator as any).deviceMemory || 'N/A',
        hardwareConcurrency: navigator.hardwareConcurrency || 'N/A',
        connectionType: connection.effectiveType || 'N/A'
    };
};
const compressImage = (file: File, quality = 0.7): Promise<File> => {
    const MAX_DIMENSION = 1920; // Cap image dimensions at 1920px
    return new Promise<File>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            if (!event.target?.result) {
                return reject(new Error("FileReader did not return a result."));
            }
            const img = new Image();
            img.src = event.target.result as string;
            img.onload = () => {
                let { width, height } = img;

                // Resize logic for large images to prevent memory issues
                if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
                    if (width > height) {
                        height = Math.round(height * (MAX_DIMENSION / width));
                        width = MAX_DIMENSION;
                    } else {
                        width = Math.round(width * (MAX_DIMENSION / height));
                        height = MAX_DIMENSION;
                    }
                }

                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                
                // Draw resized image
                ctx.drawImage(img, 0, 0, width, height);
                
                canvas.toBlob((blob) => {
                    if (blob) {
                        const compressedFile = new File([blob], file.name, {
                            type: 'image/jpeg',
                            lastModified: Date.now(),
                        });
                        // Only use compressed file if it's smaller
                        if (compressedFile.size < file.size) {
                            resolve(compressedFile);
                        } else {
                            resolve(file);
                        }
                    } else {
                        reject(new Error('Canvas to Blob conversion failed'));
                    }
                }, 'image/jpeg', quality);
            };
            img.onerror = () => reject(new Error(`Image could not be loaded. Please ensure it is a valid image file: ${file.name}`));
        };
        reader.onerror = () => reject(reader.error || new Error(`File could not be read: ${file.name}`));
    });
};

/**
 * Calculates the distance between two GPS coordinates in kilometers using the Haversine formula.
 */
const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
};

// --- Shared Form Control Styling & Components ---
const formInputStyles = "mt-2 block w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 px-4 py-3 text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:border-brand-500 focus:ring-1 focus:ring-brand-500 sm:text-base transition-colors duration-200 ease-in-out";

const FormInput: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <input {...props} className={`${formInputStyles} ${props.className || ''}`} />
);
const FormTextarea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => (
  <textarea {...props} className={`${formInputStyles} ${props.className || ''}`}></textarea>
);
const FormSelect: React.FC<React.SelectHTMLAttributes<HTMLSelectElement>> = (props) => (
  <select {...props} className={`${formInputStyles} disabled:bg-gray-200 dark:disabled:bg-gray-600 disabled:cursor-not-allowed ${props.className || ''}`} />
);
const FormLabel: React.FC<React.LabelHTMLAttributes<HTMLLabelElement>> = (props) => (
  <label {...props} className={`block text-sm font-medium text-gray-700 dark:text-gray-200 ${props.className || ''}`} />
);

// --- Child Components (Moved outside of ReportForm for stability) ---

const Stepper: React.FC<{ currentStep: number }> = ({ currentStep }) => {
    const steps = [
        { num: 1, title: 'Report Type', icon: <FlagIcon className="w-6 h-6" /> },
        { num: 2, title: 'Suspect Details', icon: <PersonIcon className="w-6 h-6" /> },
        { num: 3, title: 'Location & Evidence', icon: <LocationIcon className="w-6 h-6" /> },
        { num: 4, title: 'Review & Submit', icon: <CheckCircleIcon className="w-6 h-6" /> },
    ];

    return (
        <nav aria-label="Progress">
            <ol role="list" className="flex items-center">
                {steps.map((step, stepIdx) => (
                    <li key={step.title} className={`relative ${stepIdx !== steps.length - 1 ? 'pr-8 sm:pr-20' : ''}`}>
                        {currentStep > step.num ? (
                             <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                <div className="h-0.5 w-full bg-brand-600" />
                            </div>
                        ) : (
                             <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                <div className="h-0.5 w-full bg-gray-200 dark:bg-gray-700" />
                            </div>
                        )}
                        <div className={`relative flex h-9 w-9 items-center justify-center rounded-full ${currentStep >= step.num ? 'bg-brand-600' : 'bg-gray-300 dark:bg-gray-600'}`} aria-current={currentStep === step.num ? "step" : undefined}>
                             <span className="text-white">{step.icon}</span>
                        </div>
                        <p className="absolute -bottom-7 w-max text-xs font-semibold text-brand-700 dark:text-brand-300">{step.title}</p>
                    </li>
                ))}
            </ol>
        </nav>
    );
};


const MathCaptcha = ({ onVerified, title = "Bot Verification" }: { onVerified: () => void, title?: string }) => {
    const [num1] = useState(Math.ceil(Math.random() * 10));
    const [num2] = useState(Math.ceil(Math.random() * 10));
    const [answer, setAnswer] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (parseInt(answer, 10) === num1 + num2) {
            setError('');
            onVerified();
        } else {
            setError('Incorrect answer. Please try again.');
            setAnswer('');
        }
    };

    return (
        <div className="text-center p-4 border rounded-lg bg-white dark:bg-gray-800 dark:border-gray-700 text-black dark:text-white">
            <h3 className="text-lg font-medium mb-2">{title}</h3>
            <p className="mb-3">To proceed, please solve the following:</p>
            <form onSubmit={handleSubmit} className="flex flex-col items-center gap-3">
                <label htmlFor="captcha" className="text-2xl font-bold">{num1} + {num2} = ?</label>
                <FormInput
                    type="number"
                    id="captcha"
                    value={answer}
                    onChange={e => setAnswer(e.target.value)}
                    className="w-24 text-center"
                    required
                    aria-label="Captcha Answer"
                />
                <button type="submit" className="w-full py-2 px-4 rounded-md shadow-sm text-sm font-medium text-white bg-gray-600 hover:bg-gray-700">Verify I'm Human</button>
                 {error && <p className="mt-2 text-sm text-red-600" role="alert">{error}</p>}
            </form>
        </div>
    );
};

const OtpVerification = ({ onVerified, phone, onDetailsChange }: { onVerified: (phoneHash: string) => void, phone: string, onDetailsChange: (e: React.ChangeEvent<HTMLInputElement>) => void }) => {
    const [step, setStep] = useState<'details' | 'otp'>('details');
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    
    const handleDetailsSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (phone && phone.length >= 10) {
            setError('');
            setStep('otp');
            console.log(`SIMULATION: Sending OTP to ${phone}`);
        } else {
            setError('Please enter a valid 10-digit phone number.');
        }
    };

    const handleOtpSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (otp === '123456') {
             setError('');
            onVerified(hashData(phone));
        } else {
            setError('Invalid OTP. Please try again.');
        }
    };
    
    return (
        <div className="p-4 border rounded-lg bg-white dark:bg-gray-800 dark:border-gray-700">
            <h3 className="text-lg font-medium mb-2 text-center text-black dark:text-white">Reporter Verification</h3>
            {step === 'details' ? (
                <form onSubmit={handleDetailsSubmit} className="space-y-3">
                    <p className="text-sm text-center text-gray-600 dark:text-gray-400">Please provide your details to continue.</p>
                    <div>
                        <label htmlFor="reporterName" className="block text-base font-semibold text-gray-800 dark:text-gray-200">Full Name</label>
                        <FormInput type="text" id="reporterName" name="reporterName" onChange={onDetailsChange} placeholder="Your full name" />
                    </div>
                    <div>
                        <label htmlFor="reporterPhone" className="block text-base font-semibold text-gray-800 dark:text-gray-200">Mobile Number</label>
                        <FormInput type="tel" id="reporterPhone" name="reporterPhone" value={phone} onChange={onDetailsChange} placeholder="e.g., 9876543210" />
                    </div>
                    <button type="submit" className="w-full flex justify-center py-2 px-4 rounded-md shadow-sm text-sm font-medium text-white bg-brand-700 hover:bg-brand-800">Get OTP</button>
                </form>
            ) : (
                <form onSubmit={handleOtpSubmit} className="space-y-3">
                    <label htmlFor="otp" className="block text-base font-semibold text-gray-800 dark:text-gray-200">Enter OTP sent to {phone}:</label>
                    <FormInput type="text" id="otp" value={otp} onChange={e => setOtp(e.target.value)} placeholder="Enter 6-digit OTP" required />
                     <p className="text-xs text-center text-gray-500 dark:text-gray-400">Demo: Use OTP <strong>123456</strong></p>
                    <button type="submit" className="w-full flex justify-center py-2 px-4 rounded-md shadow-sm text-sm font-medium text-white bg-brand-700 hover:bg-brand-800">Verify</button>
                </form>
            )}
            {error && <p className="mt-2 text-sm text-red-600 text-center" role="alert">{error}</p>}
        </div>
    );
};

// --- Main Form Component ---

interface ReportFormProps {
    onReportSubmit: (report: ReportData) => void;
    isGeoBlocked: boolean | null;
    maliciousReporterDb: Record<string, number>;
    ipAddress: string | null;
    ipCoords: LocationCoords | null;
}

const initialFormData = {
    name: '', age: '', gender: '', clothing: '', language: '',
    skinColor: '', eyeColor: '', height: '', facialDetails: '', visibleMarks: '',
    distinguishingFeatures: '', vehicleDetails: '',
    state: '', city: '', pincode: '', manualAddress: '',
    description: '',
    reporterName: '', reporterPhone: '',
};

const ReportForm: React.FC<ReportFormProps> = ({ onReportSubmit, isGeoBlocked, maliciousReporterDb, ipAddress, ipCoords }) => {
  const [step, setStep] = useState(1);
  const [reportType, setReportType] = useState<'Illegal Immigrant' | 'Suspicious Person' | null>(null);
  const [isHumanVerified, setIsHumanVerified] = useState(false);
  const [identity, setIdentity] = useState<{ tier: IdentityTier, phoneHash?: string, name?: string, phone?: string } | null>(null);
  const [authMethod, setAuthMethod] = useState<'otp' | 'captcha' | null>(null);
  const [formData, setFormData] = useState(initialFormData);
  const [landmarkPhoto, setLandmarkPhoto] = useState<File | null>(null);
  const [evidencePhotos, setEvidencePhotos] = useState<File[]>([]);
  const [gps, setGps] = useState<LocationCoords | null>(null);
  const [locationStatus, setLocationStatus] = useState('Initializing GPS...');
  const [isSpoofingSuspected, setIsSpoofingSuspected] = useState(false);
  const [pincodeStatus, setPincodeStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [pincodeError, setPincodeError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [submitError, setSubmitError] = useState('');
  const [hasAgreed, setHasAgreed] = useState(false);
  
  // State for new explicit file upload flow
  const [selectedLandmarkFile, setSelectedLandmarkFile] = useState<File | null>(null);
  const [landmarkUploadStatus, setLandmarkUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [landmarkUploadError, setLandmarkUploadError] = useState('');
  const [selectedEvidenceFiles, setSelectedEvidenceFiles] = useState<File[]>([]);
  const [evidenceUploadStatus, setEvidenceUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [evidenceUploadError, setEvidenceUploadError] = useState('');
  const [step3Error, setStep3Error] = useState('');

  const deviceFingerprint = getDeviceFingerprint();

  const resetForm = () => {
    setStep(1);
    setReportType(null);
    setIsHumanVerified(false);
    setIdentity(null);
    setAuthMethod(null);
    setFormData(initialFormData);
    setLandmarkPhoto(null);
    setEvidencePhotos([]);
    setGps(null);
    setLocationStatus('Initializing GPS...');
    setIsSpoofingSuspected(false);
    setPincodeStatus('idle');
    setPincodeError('');
    setIsSubmitting(false);
    setSubmissionStatus('idle');
    setSubmitError('');
    setHasAgreed(false);
  };

  const simulateSaveToDatabase = (stepName: string, data: any) => {
    console.log(`SIMULATION: Saving ${stepName} data to database...`, data);
  };

  const nextStep = () => {
    setStep3Error(''); // Clear previous errors
    if (step === 3) {
      if (!landmarkPhoto || evidencePhotos.length === 0) {
        setStep3Error('Please upload both a landmark photo and at least one evidence photo to continue.');
        return;
      }
       simulateSaveToDatabase('Location & Evidence', { state: formData.state, city: formData.city, gps, hasLandmark: !!landmarkPhoto, evidenceCount: evidencePhotos.length });
    }
    if (step === 2) {
       simulateSaveToDatabase('Suspect Details', { name: formData.name, age: formData.age, gender: formData.gender /* ...etc */ });
    }
    setStep(s => s + 1);
  };

  const prevStep = () => {
    setStep(s => s - 1);
  };


  // --- Handlers ---
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({...prev, [name]: value, city: '', pincode: '' }));
  };
  
    // --- New explicit file upload handlers ---
  const handleLandmarkFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          setSelectedLandmarkFile(e.target.files[0]);
          setLandmarkUploadStatus('idle'); // Reset status on new file select
          setLandmarkPhoto(null); // Clear previous successful upload
      }
  };

  const handleEvidenceFilesSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files) {
          const files = Array.from(e.target.files).slice(0, 3);
          setSelectedEvidenceFiles(files);
          setEvidenceUploadStatus('idle'); // Reset status on new file select
          setEvidencePhotos([]); // Clear previous successful uploads
      }
  };

  const handleLandmarkUpload = async () => {
      if (!selectedLandmarkFile) return;
      setLandmarkUploadStatus('uploading');
      setLandmarkUploadError('');
      try {
          const compressedFile = await compressImage(selectedLandmarkFile);
          setLandmarkPhoto(compressedFile);
          setLandmarkUploadStatus('success');
          setSelectedLandmarkFile(null);
      } catch (error) {
          console.error("Landmark image processing failed", error);
          logError(error, { component: 'ReportForm', function: 'handleLandmarkUpload' });
          setLandmarkUploadError('Failed to process image. Please try another file.');
          setLandmarkUploadStatus('error');
      }
  };

  const handleEvidenceUpload = async () => {
      if (selectedEvidenceFiles.length === 0) return;
      setEvidenceUploadStatus('uploading');
      setEvidenceUploadError('');
      try {
          const compressedFiles: File[] = [];
          for (const file of selectedEvidenceFiles) {
              const compressed = await compressImage(file);
              compressedFiles.push(compressed);
          }
          setEvidencePhotos(compressedFiles);
          setEvidenceUploadStatus('success');
          setSelectedEvidenceFiles([]);
      } catch (error) {
          console.error("Evidence images processing failed", error);
          logError(error, { component: 'ReportForm', function: 'handleEvidenceUpload' });
          setEvidenceUploadError('Failed to process one or more images. Please try again.');
          setEvidenceUploadStatus('error');
      }
  };

  const handleGetLocation = useCallback(() => {
    setLocationStatus('Fetching location...');
    navigator.geolocation.getCurrentPosition(
      pos => {
        let spoofingDetected = false;
        let spoofingReason = '';

        // 1. Check timestamp (if older than 60s, it might be a cached/mocked value)
        if (Date.now() - pos.timestamp > 60000) {
            spoofingDetected = true;
            spoofingReason = 'Stale GPS data detected.';
        }

        // 2. Check accuracy (suspiciously perfect or extremely poor)
        if (pos.coords.accuracy < 5) {
            spoofingDetected = true;
            spoofingReason = 'Unusually high GPS accuracy detected (possible mock location).';
        } else if (pos.coords.accuracy > 5000) {
            spoofingDetected = true;
            spoofingReason = 'GPS signal is too weak for a reliable report.';
        }
        
        // 3. Compare with IP-based location (if available)
        // A large discrepancy might indicate a VPN or GPS spoofing.
        if (ipCoords) {
            const distance = getDistance(
                pos.coords.latitude, pos.coords.longitude,
                ipCoords.latitude, ipCoords.longitude
            );
            // Over 200km is a major discrepancy. This allows for some inaccuracy in IP-based location.
            if (distance > 200) {
                spoofingDetected = true;
                spoofingReason = `GPS location is over ${Math.round(distance)}km away from your network location. Disable any VPNs.`;
            }
        }

        setIsSpoofingSuspected(spoofingDetected);
        setGps({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });

        if (spoofingDetected) {
            setLocationStatus(`Warning: ${spoofingReason} Credibility may be affected.`);
        } else {
            setLocationStatus(`GPS Locked: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
        }
      },
      () => setLocationStatus('Could not get location. Please enable GPS and refresh.'),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 } // maximumAge: 0 forces a fresh reading
    );
  }, [ipCoords]);

  useEffect(() => {
    if(step > 1) handleGetLocation();
  }, [step, handleGetLocation]);

  useEffect(() => {
    const fetchPincodeData = async () => {
      if (formData.pincode.length !== 6) {
        if (pincodeStatus === 'success') {
          setFormData(prev => ({...prev, state: '', city: ''}));
        }
        setPincodeStatus('idle');
        setPincodeError('');
        return;
      }
  
      setPincodeStatus('loading');
      setPincodeError('');
  
      try {
        const response = await fetch(`https://api.postalpincode.in/pincode/${formData.pincode}`);
        if (!response.ok) throw new Error('Network response was not ok.');
        
        const data = await response.json();
        
        if (data && data[0]?.Status === 'Success') {
          const postOffice = data[0].PostOffice[0];
          setFormData(prev => ({
            ...prev,
            state: postOffice.State,
            city: postOffice.District,
          }));
          setPincodeStatus('success');
        } else {
          setPincodeError(data[0]?.Message || 'Invalid Pincode. Please check and try again.');
          setPincodeStatus('error');
          setFormData(prev => ({ ...prev, state: '', city: '' }));
        }
      } catch (error) {
        setPincodeError('Failed to verify pincode due to a network error. Please try again later.');
        setPincodeStatus('error');
        setFormData(prev => ({ ...prev, state: '', city: '' }));
      }
    };
  
    const timer = setTimeout(() => {
        fetchPincodeData();
    }, 500); // Debounce API call

    return () => clearTimeout(timer);
  }, [formData.pincode]);

  
  const calculateCredibility = (report: Omit<ReportData, 'caseId' | 'submissionTimestamp' | 'reporter'> & {reporter: typeof identity}) => {
    let score = 0;
    if (!report.reporter) return 0;
    if(report.reporter.tier === 'Tier 2') score += 15;
    else if(report.reporter.tier === 'Tier 3') score += 5;
    
    if (report.location.autoGps) score += 20;
    if (isSpoofingSuspected) {
        score -= 30; // Heavy penalty for spoofing
    }
    
    if (report.evidencePhotos.length > 0 && report.location.landmarkPhoto) score += 20;
    if (report.location.description.length >= 50) score += 15;
    if (report.riskFactors.includes("High-risk location")) score += 10;
    
    return Math.max(0, Math.min(score, 100)); // Clamp score between 0 and 100
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identity || !reportType) return;

    // --- ABUSE DETERRENCE CHECKS ---
    const submissionHistory: number[] = JSON.parse(localStorage.getItem('submissionHistory') || '[]');
    const now = Date.now();
    const submissionsInLast24h = submissionHistory.filter(ts => now - ts < 24 * 60 * 60 * 1000);
    if (submissionsInLast24h.length >= 2) {
        setSubmitError("Rate limit exceeded. Please try again in 24 hours.");
        return;
    }

    const reporterId = identity.phoneHash || deviceFingerprint;
    if ((maliciousReporterDb[reporterId] || 0) >= 4) {
        setSubmitError("Your account has been flagged for submitting false reports. You are blocked from making new submissions.");
        return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
        const landmarkPhotoHashed = landmarkPhoto ? { file: landmarkPhoto, hash: await hashFile(landmarkPhoto), timestamp: new Date() } : null;
        const evidencePhotosHashed = await Promise.all(
            evidencePhotos.map(async file => ({ file, hash: await hashFile(file), timestamp: new Date() }))
        );
        
        const riskFactors: string[] = [];
        if (HIGH_RISK_PINCODES.includes(formData.pincode)) {
            riskFactors.push("High-risk location");
        }
        if (isSpoofingSuspected) {
            riskFactors.push("Suspected GPS Spoofing");
        }

        const partialReport = {
            reportType,
            priority: 'LOW' as 'LOW',
            credibilityScore: 0,
            reporter: identity,
            suspect: {
                name: formData.name, age: formData.age, gender: formData.gender as any,
                clothing: formData.clothing, language: formData.language,
                skinColor: formData.skinColor, eyeColor: formData.eyeColor, height: formData.height,
                facialDetails: formData.facialDetails, visibleMarks: formData.visibleMarks,
                distinguishingFeatures: formData.distinguishingFeatures,
                vehicleDetails: formData.vehicleDetails,
            },
            location: {
                autoGps: gps, landmarkPhoto: landmarkPhotoHashed,
                dateTime: new Date(), description: formData.description,
                state: formData.state, city: formData.city, pincode: formData.pincode, manualAddress: formData.manualAddress,
            },
            evidencePhotos: evidencePhotosHashed,
            riskFactors,
            triageStatus: 'Pending' as 'Pending',
            reportStatus: 'Pending' as 'Pending'
        };
        
        const score = calculateCredibility(partialReport);

        if (score < 45) {
            setSubmitError(`Submission failed: Credibility score (${score}) is too low. Please provide more details, photos, and ensure GPS is enabled.`);
            setIsSubmitting(false);
            return;
        }

        const finalReport: ReportData = {
            ...partialReport,
            caseId: generateCaseId(),
            submissionTimestamp: new Date(),
            credibilityScore: score,
            priority: score >= 70 || riskFactors.length > 0 ? 'HIGH' : 'LOW',
            reporter: {
                ...identity,
                deviceFingerprint,
                ipAddress: ipAddress || 'N/A',
                browserMetadata: getBrowserMetadata(),
            }
        };
        
        simulateSaveToDatabase('Final Report', finalReport);
        
        const stateEmail = STATE_POLICE_EMAILS[finalReport.location.state] || 'dgp.ho@gov.in.simulated';
        console.log(`SIMULATION: Sending report ${finalReport.caseId} to ${stateEmail} and nodal_officer@mha.gov.in.simulated`);

        setTimeout(() => {
            onReportSubmit(finalReport);
            localStorage.setItem('submissionHistory', JSON.stringify([...submissionsInLast24h, now]));
            setIsSubmitting(false);
            setSubmissionStatus('success');
        }, 1500);
    } catch (error) {
        console.error("Submission error:", error);
        logError(error, {
            component: 'ReportForm',
            function: 'handleSubmit',
            context: { step, reportType },
        });
        setSubmitError("A critical error occurred while processing your report. Please refresh and try again. The issue has been logged.");
        setIsSubmitting(false);
        setSubmissionStatus('error');
    }
  };
  
  // --- Render Logic ---

  if (isGeoBlocked === null) {
      return <div className="text-center p-8">Checking your location...</div>
  }
  if (isGeoBlocked) {
    return <div className="text-center p-8 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-lg">
        <h2 className="font-bold text-xl">Access Denied</h2>
        <p>This service is only available for reporting from within India.</p>
    </div>
  }

  if (submissionStatus === 'success') {
    return (
        <div className="bg-white dark:bg-gray-800 max-w-2xl mx-auto p-8 rounded-lg shadow-lg text-center">
            <h2 className="text-2xl font-bold text-green-600 mb-4">Report Submitted Successfully!</h2>
            <p className="text-gray-700 dark:text-gray-300">Thank you for your vigilance. Your report has been received and assigned a case ID.</p>
            <button onClick={resetForm} className="mt-6 inline-flex items-center px-6 py-2 border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-700 hover:bg-brand-800">Submit Another Report</button>
        </div>
    );
  }

  const FormWrapper: React.FC<{children: React.ReactNode, title?: string}> = ({children, title}) => (
     <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md animate-fade-in text-black dark:text-white" role="form" aria-labelledby={title ? 'form-title' : undefined}>
        {title && <h2 id="form-title" className="text-xl font-semibold border-b pb-3 mb-6 text-brand-800 dark:text-brand-300">{title}</h2>}
        {children}
    </div>
  );

  const ReviewDetails = () => (
    <div className="space-y-4 text-sm p-4 border rounded-md bg-gray-50 dark:bg-gray-700 dark:border-gray-600 mb-6">
        <h3 className="font-bold text-md mb-2">Review Your Report</h3>
        <p><strong>Reporting:</strong> {reportType}</p>
        <p><strong>Gender:</strong> {formData.gender || 'N/A'}</p>
        <p><strong>Location:</strong> {formData.city || 'N/A'}, {formData.state || 'N/A'}</p>
        <p><strong>Photos:</strong> {landmarkPhoto ? 1 : 0} Landmark, {evidencePhotos.length} Evidence</p>
        <p><strong>Description:</strong> {formData.description.substring(0, 100)}...</p>
    </div>
  );

  const renderContent = () => {
    if (!reportType) {
        return (
             <FormWrapper title="What would you like to report?">
                <div className="flex flex-col sm:flex-row gap-4">
                    <button type="button" onClick={() => setReportType('Illegal Immigrant')} className="w-full py-4 px-4 rounded-md shadow-sm text-lg font-medium text-white bg-brand-800 hover:bg-brand-900">Report Illegal Immigrant</button>
                    <button type="button" onClick={() => setReportType('Suspicious Person')} className="w-full py-4 px-4 rounded-md shadow-sm text-lg font-medium text-white bg-gray-600 hover:bg-gray-700">Report Suspicious Person</button>
                </div>
            </FormWrapper>
        );
    }
    
    if (!isHumanVerified) {
        return <MathCaptcha onVerified={() => { setIsHumanVerified(true); nextStep(); }} title="Human Verification" />;
    }
    
    // Step 4 - Part 1: Identity Verification (no <form> wrapper)
    // This prevents nested forms, which is invalid HTML and causes submission bugs.
    if (step === 4 && !identity) {
        return (
            <FormWrapper title="Step 4: Review & Submit">
                <ReviewDetails />
                <div className="max-w-md mx-auto">
                    <h2 className="text-xl font-semibold text-center mb-4">Choose Your Reporting Method</h2>
                    {!authMethod ? (
                        <div className="flex flex-col space-y-4">
                            <button type="button" onClick={() => setAuthMethod('otp')} className="w-full py-3 px-4 rounded-md shadow-sm text-lg font-medium text-white bg-brand-800 hover:bg-brand-900">Report with Phone OTP (+15 Pts)</button>
                            <button type="button" onClick={() => setAuthMethod('captcha')} className="w-full py-3 px-4 rounded-md shadow-sm text-lg font-medium text-white bg-gray-600 hover:bg-gray-700">Report Anonymously (+5 Pts)</button>
                        </div>
                    ) : authMethod === 'otp' ? (
                        <OtpVerification 
                            phone={formData.reporterPhone}
                            onDetailsChange={handleInputChange}
                            onVerified={(phoneHash) => setIdentity({ tier: 'Tier 2', phoneHash, name: formData.reporterName, phone: formData.reporterPhone })} 
                        />
                    ) : (
                        <MathCaptcha onVerified={() => setIdentity({ tier: 'Tier 3' })} />
                    )}
                </div>
                <div className="mt-8">
                    <button type="button" onClick={prevStep} className="inline-flex justify-center py-2 px-6 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 border border-gray-300 dark:border-gray-600">Previous</button>
                </div>
            </FormWrapper>
        );
    }

    // Main form for steps 2, 3, and the final part of step 4
    return (
      <form onSubmit={handleSubmit} className="space-y-8">
        {step === 2 && (
            <FormWrapper title="Step 2: Suspect Details">
              <fieldset>
                <legend className="sr-only">Details about the suspect</legend>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                    <div>
                        <FormLabel htmlFor="name">Name (Optional)</FormLabel>
                        <FormInput id="name" name="name" value={formData.name} onChange={handleInputChange} placeholder="Full Name"/>
                    </div>
                    <div>
                        <FormLabel htmlFor="age">Approx. Age</FormLabel>
                        <FormInput id="age" name="age" value={formData.age} onChange={handleInputChange} placeholder="e.g., 35-40"/>
                    </div>
                    <div>
                        <FormLabel htmlFor="gender">Gender</FormLabel>
                        <FormSelect id="gender" name="gender" value={formData.gender} onChange={handleInputChange}><option value="">Select Gender</option><option>Male</option><option>Female</option><option>Other</option></FormSelect>
                    </div>
                    <div>
                        <FormLabel htmlFor="height">Approx. Height</FormLabel>
                        <FormInput id="height" name="height" value={formData.height} onChange={handleInputChange} placeholder="e.g., 5ft 10in" />
                    </div>
                    <div>
                        <FormLabel htmlFor="skinColor">Skin Color</FormLabel>
                        <FormInput id="skinColor" name="skinColor" value={formData.skinColor} onChange={handleInputChange} placeholder="e.g., Wheatish, Fair, Dark" />
                    </div>
                    <div>
                        <FormLabel htmlFor="eyeColor">Eye Color</FormLabel>
                        <FormInput id="eyeColor" name="eyeColor" value={formData.eyeColor} onChange={handleInputChange} placeholder="e.g., Brown, Black" />
                    </div>
                    <div className="sm:col-span-2">
                        <FormLabel htmlFor="language">Language Spoken</FormLabel>
                        <FormInput id="language" name="language" value={formData.language} onChange={handleInputChange} placeholder="e.g., Bengali, Hindi with accent" />
                    </div>
                    <div className="sm:col-span-2">
                        <FormLabel htmlFor="clothing">Clothing Description</FormLabel>
                        <FormTextarea id="clothing" name="clothing" value={formData.clothing} onChange={handleInputChange} placeholder="e.g., Blue checked shirt, grey trousers" rows={2}></FormTextarea>
                    </div>
                    <div className="sm:col-span-2">
                        <FormLabel htmlFor="facialDetails">Facial Details</FormLabel>
                        <FormTextarea id="facialDetails" name="facialDetails" value={formData.facialDetails} onChange={handleInputChange} placeholder="e.g., Thick beard, scar on left cheek" rows={2}></FormTextarea>
                    </div>
                    <div className="sm:col-span-2">
                        <FormLabel htmlFor="visibleMarks">Visible Marks or Tattoos</FormLabel>
                        <FormTextarea id="visibleMarks" name="visibleMarks" value={formData.visibleMarks} onChange={handleInputChange} placeholder="e.g., Dragon tattoo on right arm" rows={2}></FormTextarea>
                    </div>
                    <div className="sm:col-span-2">
                        <FormLabel htmlFor="distinguishingFeatures">Distinguishing Features</FormLabel>
                        <FormTextarea id="distinguishingFeatures" name="distinguishingFeatures" value={formData.distinguishingFeatures} onChange={handleInputChange} placeholder="e.g., Walks with a limp, specific mannerisms" rows={2}></FormTextarea>
                    </div>
                    <div className="sm:col-span-2">
                        <FormLabel htmlFor="vehicleDetails">Vehicle Details</FormLabel>
                        <FormTextarea id="vehicleDetails" name="vehicleDetails" value={formData.vehicleDetails} onChange={handleInputChange} placeholder="e.g., Make, Model, Color, License Plate" rows={2}></FormTextarea>
                    </div>
                </div>
              </fieldset>
                 <div className="mt-8 flex justify-between">
                    <button type="button" onClick={prevStep} className="inline-flex justify-center py-2 px-6 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 border border-gray-300 dark:border-gray-600">Previous</button>
                    <button type="button" onClick={nextStep} className="inline-flex justify-center py-2 px-6 rounded-md shadow-sm text-sm font-medium text-white bg-brand-700 hover:bg-brand-800">Next</button>
                </div>
            </FormWrapper>
        )}

        {step === 3 && (
             <FormWrapper title="Step 3: Location & Evidence">
              <fieldset>
                <legend className="sr-only">Location and evidence details</legend>
                 <div className="space-y-6">
                    <div className="space-y-2">
                        <button type="button" onClick={handleGetLocation} className="w-full inline-flex items-center justify-center px-4 py-2 border rounded-md font-medium text-gray-700 dark:text-gray-200 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 dark:border-gray-600">
                           {locationStatus.startsWith('Warning:') ? 'Re-fetch GPS' : 'Fetch Current GPS'}
                        </button>
                         <p className={`text-center text-sm min-h-[20px] ${isSpoofingSuspected ? 'text-yellow-600 dark:text-yellow-400 font-semibold' : 'text-gray-600 dark:text-gray-400'}`}>
                           {locationStatus}
                         </p>
                    </div>
                    
                    <div>
                        <FormLabel htmlFor="pincode">6-digit Pincode</FormLabel>
                        <FormInput
                            id="pincode"
                            name="pincode"
                            value={formData.pincode}
                            onChange={handleInputChange}
                            placeholder="Enter Pincode to Autofill Location"
                            type="tel"
                            maxLength={6}
                            pattern="[0-9]{6}"
                            title="Please enter a valid 6-digit pincode."
                            aria-describedby="pincode-status"
                        />
                        <div id="pincode-status" className="mt-1 text-sm h-5" aria-live="polite">
                          {pincodeStatus === 'loading' && <p className="text-gray-500 dark:text-gray-400">Verifying pincode...</p>}
                          {pincodeStatus === 'success' && <p className="text-green-600">State and City auto-filled.</p>}
                          {pincodeStatus === 'error' && <p className="text-red-600">{pincodeError}</p>}
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <FormLabel htmlFor="state">State</FormLabel>
                            <FormSelect id="state" name="state" value={formData.state} onChange={handleStateChange} disabled={pincodeStatus === 'success'}>
                                <option value="">Select State</option>
                                {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                            </FormSelect>
                        </div>
                        <div>
                             <FormLabel htmlFor="city">City</FormLabel>
                             <FormSelect id="city" name="city" value={formData.city} onChange={handleInputChange} disabled={pincodeStatus === 'success' || !formData.state}>
                                <option value="">Select City</option>
                                {(STATE_CITY_MAP[formData.state] || [formData.city]).map(c => <option key={c} value={c}>{c}</option>)}
                             </FormSelect>
                         </div>
                    </div>
                    
                    <div>
                        <FormLabel htmlFor="manualAddress">Complete Address / Place of Identification</FormLabel>
                        <FormTextarea id="manualAddress" name="manualAddress" value={formData.manualAddress} onChange={handleInputChange} placeholder="e.g., Near bus stand, opposite bank" rows={2}></FormTextarea>
                    </div>
                    
                    <div>
                        <FormLabel htmlFor="landmark-photo">Photo of Landmark *</FormLabel>
                        <div className="mt-2 flex flex-wrap items-center gap-4">
                            <input type="file" onChange={handleLandmarkFileSelect} accept="image/*" id="landmark-photo" className="flex-grow min-w-0 block w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100 dark:file:bg-gray-700 dark:file:text-brand-200 dark:hover:file:bg-gray-600"/>
                            <button type="button" onClick={handleLandmarkUpload} disabled={!selectedLandmarkFile || landmarkUploadStatus === 'uploading'} className="inline-flex justify-center py-2 px-4 rounded-md shadow-sm text-sm font-medium text-white bg-brand-700 hover:bg-brand-800 disabled:bg-gray-400 dark:disabled:bg-gray-500 disabled:cursor-not-allowed">
                                {landmarkUploadStatus === 'uploading' ? 'Uploading...' : 'Upload'}
                            </button>
                        </div>
                        <div className="mt-2 text-sm min-h-[20px]" aria-live="polite">
                            {landmarkUploadStatus === 'success' && landmarkPhoto && <p className="text-green-600 flex items-center"><CheckCircleIcon className="w-5 h-5 mr-1" /> Uploaded: {landmarkPhoto.name}</p>}
                            {landmarkUploadStatus === 'error' && <p className="text-red-600">{landmarkUploadError}</p>}
                        </div>
                    </div>

                    <div>
                        <FormLabel htmlFor="evidence-photos">Evidence Photos (1 required, up to 3) *</FormLabel>
                        <div className="mt-2 flex flex-wrap items-center gap-4">
                            <input type="file" multiple onChange={handleEvidenceFilesSelect} accept="image/*" id="evidence-photos" className="flex-grow min-w-0 block w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100 dark:file:bg-gray-700 dark:file:text-brand-200 dark:hover:file:bg-gray-600"/>
                            <button type="button" onClick={handleEvidenceUpload} disabled={selectedEvidenceFiles.length === 0 || evidenceUploadStatus === 'uploading'} className="inline-flex justify-center py-2 px-4 rounded-md shadow-sm text-sm font-medium text-white bg-brand-700 hover:bg-brand-800 disabled:bg-gray-400 dark:disabled:bg-gray-500 disabled:cursor-not-allowed">
                                {evidenceUploadStatus === 'uploading' ? 'Uploading...' : `Upload ${selectedEvidenceFiles.length} file(s)`}
                            </button>
                        </div>
                        <div className="mt-2 text-sm min-h-[20px]" aria-live="polite">
                            {evidenceUploadStatus === 'success' && evidencePhotos.length > 0 && <p className="text-green-600 flex items-center"><CheckCircleIcon className="w-5 h-5 mr-1" /> Uploaded {evidencePhotos.length} photo(s).</p>}
                            {evidenceUploadStatus === 'error' && <p className="text-red-600">{evidenceUploadError}</p>}
                        </div>
                        {evidencePhotos.length > 0 && (
                            <ul className="mt-2 list-disc list-inside text-xs text-gray-600 dark:text-gray-400">
                                {evidencePhotos.map(f => <li key={f.name}>{f.name} ({(f.size / 1024).toFixed(1)} KB)</li>)}
                            </ul>
                        )}
                    </div>

                    <div>
                        <FormLabel htmlFor="description">Detailed Description</FormLabel>
                        <FormTextarea id="description" name="description" value={formData.description} onChange={handleInputChange} placeholder="Detailed Description of the situation and suspect's behavior" rows={4}></FormTextarea>
                    </div>
                 </div>
                </fieldset>
                 <div className="mt-8 flex justify-between items-center">
                    <button type="button" onClick={prevStep} className="inline-flex justify-center py-2 px-6 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 border border-gray-300 dark:border-gray-600">Previous</button>
                    {step3Error && <p className="text-red-600 text-sm font-semibold text-center" role="alert">{step3Error}</p>}
                    <button type="button" onClick={nextStep} className="inline-flex justify-center py-2 px-6 rounded-md shadow-sm text-sm font-medium text-white bg-brand-700 hover:bg-brand-800">Next</button>
                </div>
            </FormWrapper>
        )}

        {step === 4 && identity && (
            <FormWrapper title="Step 4: Review & Submit">
                <ReviewDetails />
                <div>
                    <div className="flex items-start my-4">
                        <div className="flex items-center h-5">
                            <input id="consent" name="consent" type="checkbox" checked={hasAgreed} onChange={(e) => setHasAgreed(e.target.checked)} className="focus:ring-brand-500 h-4 w-4 text-brand-600 border-gray-400 dark:border-gray-500 rounded"/>
                        </div>
                        <div className="ml-3 text-sm">
                            <label htmlFor="consent" className="font-medium text-gray-700 dark:text-gray-300">I confirm this report is true to my knowledge.</label>
                            <p className="text-gray-500 dark:text-gray-400">Filing a false report is a punishable offense.</p>
                        </div>
                    </div>
                    {submitError && <p className="text-red-600 text-center font-semibold mb-4" role="alert">{submitError}</p>}
                    <button type="submit" disabled={isSubmitting || !hasAgreed} className="w-full flex justify-center py-3 px-4 rounded-md shadow-sm text-lg font-medium text-white bg-brand-700 hover:bg-brand-800 disabled:bg-brand-400 disabled:cursor-not-allowed">
                        {isSubmitting ? 'Analyzing & Submitting...' : 'Submit Secure Report'}
                    </button>
                </div>
                 <div className="mt-8">
                    <button type="button" onClick={prevStep} className="inline-flex justify-center py-2 px-6 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 border border-gray-300 dark:border-gray-600">Previous</button>
                </div>
            </FormWrapper>
        )}
    </form>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      {isHumanVerified && (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md mb-8 flex justify-center">
            <Stepper currentStep={step} />
        </div>
      )}
      {renderContent()}
    </div>
  );
};

export default ReportForm;