// A simple, no-op service worker that takes immediate control.
// In a real-world PWA, you would add caching strategies here.

const CACHE_NAME = 'suspect-reporter-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  // Add other static assets you want to cache here
];

self.addEventListener('install', event => {
  // Perform install steps
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});

self.addEventListener('activate', event => {
  console.log('Service worker activating...');
});
