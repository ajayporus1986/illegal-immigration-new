interface LoggedError {
  message: string;
  stack?: string;
  timestamp: string;
  context?: Record<string, any>;
  url: string;
}

const getErrorLogs = (): LoggedError[] => {
  try {
    const logs = localStorage.getItem('error_logs');
    return logs ? JSON.parse(logs) : [];
  } catch (e) {
    return [];
  }
};

const saveErrorLogs = (logs: LoggedError[]) => {
  try {
    // Keep only the last 20 logs to prevent localStorage from filling up
    const trimmedLogs = logs.slice(-20);
    localStorage.setItem('error_logs', JSON.stringify(trimmedLogs));
  } catch (e) {
    console.error("Failed to save error logs to localStorage", e);
  }
};

/**
 * Logs an error with context, saving it to localStorage for debugging.
 * @param error - The error object.
 * @param context - Optional additional information about the error context.
 */
export const logError = (error: unknown, context?: Record<string, any>): void => {
  let errorToLog: Partial<LoggedError>;

  if (error instanceof Error) {
    errorToLog = {
      message: error.message,
      stack: error.stack,
    };
  } else {
    errorToLog = {
      message: `Non-error object thrown: ${String(error)}`,
    };
  }
  
  const loggedError: LoggedError = {
    ...errorToLog,
    timestamp: new Date().toISOString(),
    context,
    url: window.location.href,
  } as LoggedError;

  // FIX: Updated console output to use JSON.stringify. This ensures the error object is logged as a readable string, preventing the unhelpful "[object Object]" message if the console attempts to coerce it.
  console.error("Caught Exception:", JSON.stringify(loggedError, null, 2));

  // In a real application, you would send this to a logging service.
  // For this simulation, we'll store it in localStorage.
  const existingLogs = getErrorLogs();
  saveErrorLogs([...existingLogs, loggedError]);
};

/**
 * Sets up global error handlers to catch unhandled exceptions and promise rejections.
 */
export const setupGlobalErrorHandlers = (): void => {
    // Catch global script errors
    window.onerror = (message, source, lineno, colno, error) => {
        logError(error || new Error(message as string), {
            source,
            lineno,
            colno,
            type: 'window.onerror'
        });
        // Return true to prevent the default browser error handling (e.g., console message)
        return true; 
    };

    // Catch unhandled promise rejections
    window.onunhandledrejection = (event: PromiseRejectionEvent) => {
        logError(event.reason, {
            type: 'unhandledrejection'
        });
        // Prevent default handling (e.g., console message)
        event.preventDefault(); 
    };

    console.log("Global error handlers have been set up.");
};